<section class="cat_nav_home" id="cat_nav_home">
    <div class="container-fluid">
        <div class="pos-rel">
            <ul class="nav nav-pills nav-fill">
                <li class="nav-item">
                    <a class="nav-link" id="seeAllMenu" href=""><i class="fas fa-bars"></i><br>See All</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Fresh Food</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Grocery</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Decor</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Toys</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Stationary</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Pet food</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Garden</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Sweets</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Dairy</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Snacks</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Electronics</a>
                </li>
            </ul>
            <div class="see-all-menu">
                <ul>
                    <li><a href="">Fresh Food</a>
                        <ul>
                            <li><a href="">Pancakes</a></li>
                            <li><a href="">Noodles</a></li>
                            <li><a href="">Cake</a></li>
                            <li><a href="">Asian noodles</a></li>
                            <li><a href="">Spinach</a></li>
                            <li><a href="">Asparagus</a></li>
                        </ul>
                    </li>
                </ul>
                <ul>
                    <li><a href="">Grocery</a>
                        <ul>
                            <li><a href="">Pancakes</a></li>
                            <li><a href="">Noodles</a></li>
                            <li><a href="">Cake</a></li>
                            <li><a href="">Asian noodles</a></li>
                            <li><a href="">Spinach</a></li>
                            <li><a href="">Asparagus</a></li>
                        </ul>
                    </li>
                </ul>
                <ul>
                    <li><a href="">Grocery</a>
                        <ul>
                            <li><a href="">Pancakes</a></li>
                            <li><a href="">Noodles</a></li>
                            <li><a href="">Cake</a></li>
                            <li><a href="">Asian noodles</a></li>
                            <li><a href="">Spinach</a></li>
                            <li><a href="">Asparagus</a></li>
                        </ul>
                    </li>
                </ul>
                <ul>
                    <li><a href="">Grocery</a>
                        <ul>
                            <li><a href="">Pancakes</a></li>
                            <li><a href="">Noodles</a></li>
                            <li><a href="">Cake</a></li>
                            <li><a href="">Asian noodles</a></li>
                            <li><a href="">Spinach</a></li>
                            <li><a href="">Asparagus</a></li>
                        </ul>
                    </li>
                </ul>
                <ul>
                    <li><a href="">Grocery</a>
                        <ul>
                            <li><a href="">Pancakes</a></li>
                            <li><a href="">Noodles</a></li>
                            <li><a href="">Cake</a></li>
                            <li><a href="">Asian noodles</a></li>
                            <li><a href="">Spinach</a></li>
                            <li><a href="">Asparagus</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>